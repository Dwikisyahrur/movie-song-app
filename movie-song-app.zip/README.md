# movie-song-app

Expo TypeScript project showing Ghibli movies and songs (iTunes).

Run:

```bash
npm install
npm start
```
