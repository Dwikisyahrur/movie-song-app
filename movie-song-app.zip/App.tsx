import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import MovieListScreen from './src/screens/MovieListScreen';
import MovieDetailScreen from './src/screens/MovieDetailScreen';
import SongListScreen from './src/screens/SongListScreen';
import type { RouteProp } from '@react-navigation/native';

export type RootStackParamList = {
  MovieList: undefined;
  MovieDetail: { id: string; title: string };
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator();

function MovieStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="MovieList" component={MovieListScreen} options={{ title: 'Movies' }} />
      <Stack.Screen name="MovieDetail" component={MovieDetailScreen} options={({ route }) => ({ title: (route as any).params?.title ?? 'Detail' })} />
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarIcon: ({ color, size }) => {
            let iconName: any = 'home';
            if (route.name === 'Movies') iconName = 'film-outline';
            else if (route.name === 'Songs') iconName = 'musical-notes-outline';
            return <Ionicons name={iconName} color={color} size={size} />;
          },
          tabBarActiveTintColor: '#2563eb',
          tabBarInactiveTintColor: 'gray',
        })}
      >
        <Tab.Screen name="Movies" component={MovieStack} />
        <Tab.Screen name="Songs" component={SongListScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
