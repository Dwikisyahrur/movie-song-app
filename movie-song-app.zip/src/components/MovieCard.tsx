import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import type { Film } from '../api/data';

type Props = {
  film: Film;
  onPress?: () => void;
};

export default function MovieCard({ film, onPress }: Props) {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      {film.image ? <Image source={{ uri: film.image }} style={styles.image} /> : null}
      <View style={{ flex: 1 }}>
        <Text numberOfLines={1} style={styles.title}>{film.title}</Text>
        <Text style={styles.meta}>{film.release_date} • {film.director}</Text>
        <Text numberOfLines={2} style={styles.desc}>{film.description}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    padding: 12,
    borderBottomWidth: 1,
    borderColor: '#e5e7eb',
    alignItems: 'center'
  },
  image: { width: 72, height: 104, borderRadius: 6, marginRight: 12, backgroundColor: '#ddd' },
  title: { fontWeight: '800', fontSize: 16 },
  meta: { color: '#6B7280', marginTop: 2 },
  desc: { color: '#374151', marginTop: 6 }
});
